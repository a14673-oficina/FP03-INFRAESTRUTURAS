<?php
/**
 * Script de Teste de Ligação à Base de Dados
 */

// Ativar reporte de erros para vermos tudo o que se passa
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Credenciais do InfinityFree
$host = 'sql300.infinityfree.com';
$user = 'if0_40156190';
$pass = 'BBQYDBr2VnSGp';
$dbname = 'if0_40156190_db_infraestrutura';

echo "<h2>Teste de Ligação à Base de Dados (PDO)</h2>";
echo "<hr>";

try {
    echo "Tentando ligar a <strong>$host</strong>...<br>";
    
    // Tenta criar a ligação
    $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $pass);
    
    // Configura o modo de erro
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "<p style='color: green; font-weight: bold;'>✅ SUCESSO: Ligação estabelecida com sucesso!</p>";
    
    // Teste extra: ver se a tabela 'login' existe
    echo "Verificando se a tabela 'login' existe...<br>";
    $query = $conn->query("SHOW TABLES LIKE 'login'");
    if ($query->rowCount() > 0) {
        echo "<p style='color: green;'>✅ A tabela 'login' foi encontrada.</p>";
        
        // Ver colunas da tabela
        echo "Colunas encontradas na tabela 'login':<br><ul>";
        $columns = $conn->query("DESCRIBE login");
        while($col = $columns->fetch(PDO::FETCH_ASSOC)) {
            echo "<li>" . $col['Field'] . " (" . $col['Type'] . ")</li>";
        }
        echo "</ul>";
    } else {
        echo "<p style='color: orange;'>⚠️ AVISO: A tabela 'login' NÃO foi encontrada na base de dados '$dbname'.</p>";
    }

} catch (PDOException $e) {
    echo "<p style='color: red; font-weight: bold;'>❌ ERRO: Não foi possível ligar à base de dados.</p>";
    echo "<strong>Mensagem de erro:</strong> " . $e->getMessage();
    
    echo "<br><br><strong>Dicas:</strong><br>";
    echo "1. Verifica se o utilizador e a senha no InfinityFree estão corretos.<br>";
    echo "2. Confirma se o Host (sql300.infinityfree.com) é mesmo este no teu painel.<br>";
    echo "3. Garante que a base de dados '$dbname' já foi criada no MySQL do painel.";
}
?>
