<?php
/**
 * Página Principal - Sistema de Gestão de Infraestrutura de Rede Escolar
 * Tema Minimalista Apple com Navbar Horizontal
 */

// Determinar página ativa
$page = isset($_GET['page']) ? $_GET['page'] : 'home';
$allowed_pages = ['home', 'salas', 'equipamentos', 'tecnicos', 'intervencoes', 'equipamentos_sem_intervencoes', 'relatorios'];

if (!in_array($page, $allowed_pages)) {
    $page = 'home';
}

// Gerir tema
if (isset($_GET['theme'])) {
    setcookie('theme', $_GET['theme'], time() + (365 * 24 * 60 * 60), '/');
    $_COOKIE['theme'] = $_GET['theme'];
}
$theme = isset($_COOKIE['theme']) ? $_COOKIE['theme'] : 'light';

// Função para gerar ícones SVG
function getIcon($type) {
    $icons = [
        'home' => '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg>',
        'folder' => '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path></svg>',
        'computer' => '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect><line x1="2" y1="20" x2="22" y2="20"></line></svg>',
        'user' => '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>',
        'tool' => '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 1 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"></path></svg>',
        'warning' => '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3.05h16.94a2 2 0 0 0 1.71-3.05L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>',
        'sun' => '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="5"></circle><line x1="12" y1="1" x2="12" y2="3"></line><line x1="12" y1="21" x2="12" y2="23"></line><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line><line x1="1" y1="12" x2="3" y2="12"></line><line x1="21" y1="12" x2="23" y2="12"></line><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line></svg>',
        'moon' => '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path></svg>',
        'logout' => '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><polyline points="16 17 21 12 16 7"></polyline><line x1="21" y1="12" x2="9" y2="12"></line></svg>',
    ];
    return $icons[$type] ?? '';
}
?>

<!DOCTYPE html>
<html lang="pt-PT">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestão de Rede Escolar</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="<?php echo $theme === 'dark' ? 'dark-theme' : ''; ?>">

    <div id="welcome-screen" class="welcome-screen">
        <div class="welcome-content">
            <div class="spinner-container">
                <div class="spinner-ball"></div>
                <div class="spinner-ball"></div>
                <div class="spinner-ball"></div>
                <div class="spinner-ball"></div>
            </div>
            <h1 class="welcome-title">A carregar, aguarde...</h1>
        </div>
    </div>

    <header class="navbar">
        <div class="navbar-container">
            <div class="navbar-logo">
                <img src="./logo.png" alt="Logo" class="logo-img">
            </div>

            <nav class="navbar-nav">
                <a href="index.php?page=home" class="nav-link <?php echo $page === 'home' ? 'active' : ''; ?>">
                    <span class="nav-icon"><?php echo getIcon('home'); ?></span>
                    <span class="nav-text">Início</span>
                </a>

                <div class="nav-group">
                    <span class="nav-group-label">Gestão</span>
                    <a href="index.php?page=salas" class="nav-link <?php echo $page === 'salas' ? 'active' : ''; ?>">
                        <span class="nav-icon"><?php echo getIcon('folder'); ?></span>
                        <span class="nav-text">Salas</span>
                    </a>
                    <a href="index.php?page=equipamentos" class="nav-link <?php echo $page === 'equipamentos' ? 'active' : ''; ?>">
                        <span class="nav-icon"><?php echo getIcon('computer'); ?></span>
                        <span class="nav-text">Equipamentos</span>
                    </a>
                    <a href="index.php?page=tecnicos" class="nav-link <?php echo $page === 'tecnicos' ? 'active' : ''; ?>">
                        <span class="nav-icon"><?php echo getIcon('user'); ?></span>
                        <span class="nav-text">Técnicos</span>
                    </a>
                    <a href="index.php?page=intervencoes" class="nav-link <?php echo $page === 'intervencoes' ? 'active' : ''; ?>">
                        <span class="nav-icon"><?php echo getIcon('tool'); ?></span>
                        <span class="nav-text">Intervenções</span>
                    </a>
                </div>

                <div class="nav-group">
                    <span class="nav-group-label">Análise</span>
                    <a href="index.php?page=equipamentos_sem_intervencoes" class="nav-link <?php echo $page === 'equipamentos_sem_intervencoes' ? 'active' : ''; ?>">
                        <span class="nav-icon"><?php echo getIcon('warning'); ?></span>
                        <span class="nav-text">Sem Intervenções</span>
                    </a>
                    <a href="index.php?page=relatorios" class="nav-link <?php echo $page === 'relatorios' ? 'active' : ''; ?>">
                        <span class="nav-icon"><?php echo getIcon('folder'); ?></span>
                        <span class="nav-text">Relatórios</span>
                    </a>
                </div>
            </nav>

            <div class="navbar-theme">
                <?php if ($theme === 'dark'): ?>
                    <a href="index.php?page=<?php echo $page; ?>&theme=light" class="theme-toggle">
                        <span class="nav-icon"><?php echo getIcon('sun'); ?></span>
                        <span class="nav-text">Claro</span>
                    </a>
                <?php else: ?>
                    <a href="index.php?page=<?php echo $page; ?>&theme=dark" class="theme-toggle">
                        <span class="nav-icon"><?php echo getIcon('moon'); ?></span>
                        <span class="nav-text">Escuro</span>
                    </a>
                <?php endif; ?>
            </div>

            <div class="nav-logout-container">
                <span class="user-info">Olá, <strong><?php echo htmlspecialchars($_SESSION['username'] ?? 'Convidado'); ?></strong></span>
                <a href="logout.php" class="btn-logout">
                    <?php echo getIcon('logout'); ?> Sair
                </a>
            </div>
        </div>
    </header>

    <main class="main-content">
        <?php
        // Incluir página correspondente
        switch ($page) {
            case 'salas':
                include 'pages/salas.php';
                break;
            case 'equipamentos':
                include 'pages/equipamentos.php';
                break;
            case 'tecnicos':
                include 'pages/tecnicos.php';
                break;
            case 'intervencoes':
                include 'pages/intervencoes.php';
                break;
            case 'equipamentos_sem_intervencoes':
                include 'pages/equipamentos_sem_intervencoes.php';
                break;
            case 'relatorios':
                include 'pages/relatorios.php';
                break;
            default:
                include 'pages/home.php';
        }
        ?>
    </main>

    <footer class="footer">
        <div class="footer-container">
            <div class="footer-section">
                <h4>OFICINA</h4>
                <p>Escola Profissional</p>
                <p class="footer-contact">Gestão de Infraestrutura de Rede Escolar</p>
            </div>

            <div class="footer-section">
                <h4>Links Úteis</h4>
                <ul class="footer-links">
                    <li><a href="index.php?page=home">Início</a></li>
                    <li><a href="index.php?page=salas">Salas</a></li>
                    <li><a href="index.php?page=equipamentos">Equipamentos</a></li>
                    <li><a href="index.php?page=tecnicos">Técnicos</a></li>
                    <li><a href="index.php?page=intervencoes">Intervenções</a></li>
                    <li><a href="index.php?page=relatorios">Relatórios</a></li>
                </ul>
            </div>

            <div class="footer-section">
                <h4>Informações</h4>
                <p>Sistema de Gestão de Infraestrutura de Rede</p>
                <p class="footer-year">© 2026 OFICINA - Escola Profissional</p>
            </div>
        </div>

        <div class="footer-bottom">
            <p>Desenvolvido para a Gestão de Redes Escolares</p>
        </div>
    </footer>

    <script>
        // Lógica da Tela de Boas-vindas e Carregamento
        window.addEventListener('load', function() {
            // Controla a tela de boas vindas
            const welcomeScreen = document.getElementById('welcome-screen');
            if (welcomeScreen) {
                // Espera 2 segundos e meio e depois faz a tela desaparecer suavemente
                setTimeout(() => {
                    welcomeScreen.style.opacity = '0';
                    welcomeScreen.style.visibility = 'hidden';
                }, 2500); 
            }
        });

        // Mostrar tela de carregamento (ampulheta) ao clicar em navegação
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', function(e) {
                const loadingScreen = document.getElementById('loading-screen');
                if (loadingScreen) {
                    loadingScreen.style.display = 'flex';
                    setTimeout(() => {
                        loadingScreen.style.display = 'none';
                    }, 1500);
                }
            });
        });
    </script>
</body>
</html>
