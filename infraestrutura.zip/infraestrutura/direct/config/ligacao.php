<?php
/**
 * Ficheiro de Configuração da Ligação à Base de Dados - PDO
 */

define('DB_HOST', 'sql300.infinityfree.com');
define('DB_USER', 'if0_40156190');
define('DB_PASS', 'BBQYDBr2VnSGp');
define('DB_NAME', 'if0_40156190_db_infraestrutura');

try {
    // Criar ligação à base de dados usando PDO
    $conn = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8", DB_USER, DB_PASS);
    
    // Configurar para lançar exceções em caso de erro (melhor para debugging)
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $conn->setAttribute(PDO::ATTR_EMULATE_PREPARES, false); // Desativar emulação de prepared statements para segurança
    
} catch (PDOException $e) {
    // Em produção, o ideal seria não mostrar o erro detalhado, mas para o teu trabalho ajuda imenso
    // Em produção, o ideal seria não mostrar o erro detalhado, mas para o teu trabalho ajuda imenso
    error_log("Erro na ligação (PDO): " . $e->getMessage()); // Registar o erro
    die("Ocorreu um erro crítico na ligação à base de dados. Por favor, tente novamente mais tarde."); // Mensagem genérica para o utilizador
}
?>
