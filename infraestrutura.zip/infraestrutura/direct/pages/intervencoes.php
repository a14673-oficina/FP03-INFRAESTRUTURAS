<?php
/**
 * Página de Gestão de Intervenções
 */
require_once __DIR__ . 
'/../config/ligacao.php';

$mensagem = '';
$tipo_mensagem = '';

// Processar formulário de inserção
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao']) && $_POST['acao'] === 'inserir') {
    $data_intervencao = trim($_POST['data_intervencao'] ?? '');
    $descricao = trim($_POST['descricao'] ?? '');
    $id_equipamento = intval($_POST['id_equipamento'] ?? 0);
    $id_tecnico = intval($_POST['id_tecnico'] ?? 0);

    // Validação
    if (empty($data_intervencao) || empty($descricao) || $id_equipamento <= 0 || $id_tecnico <= 0) {
        $mensagem = 'Por favor, preencha todos os campos obrigatórios.';
        $tipo_mensagem = 'error';
    } else {
        try {
            // Inserir na base de dados usando PDO
            $sql = "INSERT INTO intervencoes (data_intervencao, descricao, id_equipamento, id_tecnico) VALUES (:data_intervencao, :descricao, :id_equipamento, :id_tecnico)";
            $stmt = $conn->prepare($sql);
            $stmt->bindParam(':data_intervencao', $data_intervencao);
            $stmt->bindParam(':descricao', $descricao);
            $stmt->bindParam(':id_equipamento', $id_equipamento, PDO::PARAM_INT);
            $stmt->bindParam(':id_tecnico', $id_tecnico, PDO::PARAM_INT);
            
            if ($stmt->execute()) {
                $mensagem = 'Intervenção registada com sucesso!';
                $tipo_mensagem = 'success';
                $_POST = array();
            } else {
                $mensagem = 'Erro ao registar intervenção: ' . implode(' - ', $stmt->errorInfo());
                $tipo_mensagem = 'error';
            }
        } catch (PDOException $e) {
            $mensagem = 'Erro na base de dados: ' . $e->getMessage();
            $tipo_mensagem = 'error';
        }
    }
}

// Processar eliminação
if (isset($_GET['eliminar'])) {
    $id_intervencao = intval($_GET['eliminar']);
    
    try {
        $sql_delete = "DELETE FROM intervencoes WHERE id_intervencao = :id_intervencao";
        $stmt_delete = $conn->prepare($sql_delete);
        $stmt_delete->bindParam(':id_intervencao', $id_intervencao, PDO::PARAM_INT);
        
        if ($stmt_delete->execute()) {
            $mensagem = 'Intervenção eliminada com sucesso!';
            $tipo_mensagem = 'success';
        } else {
            $mensagem = 'Erro ao eliminar intervenção: ' . implode(' - ', $stmt_delete->errorInfo());
            $tipo_mensagem = 'error';
        }
    } catch (PDOException $e) {
        $mensagem = 'Erro na base de dados: ' . $e->getMessage();
        $tipo_mensagem = 'error';
    }
}

// Filtro por técnico
$filtro_tecnico = isset($_GET['tecnico']) ? intval($_GET['tecnico']) : 0;

// Obter lista de equipamentos para o formulário
$equipamentos_options = [];
try {
    $sql_equipamentos = "SELECT e.id_equipamento, e.tipo, e.marca, e.modelo, e.endereco_ip, s.nome_sala 
                         FROM equipamentos e 
                         LEFT JOIN salas s ON e.id_sala = s.id_sala 
                         ORDER BY s.nome_sala ASC, e.tipo ASC";
    $stmt_equipamentos = $conn->query($sql_equipamentos);
    $equipamentos_options = $stmt_equipamentos->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $mensagem = 'Erro ao carregar equipamentos: ' . $e->getMessage();
    $tipo_mensagem = 'error';
}

// Obter lista de técnicos para o formulário
$tecnicos_options = [];
try {
    $sql_tecnicos = "SELECT id_tecnico, nome FROM tecnicos ORDER BY nome ASC";
    $stmt_tecnicos = $conn->query($sql_tecnicos);
    $tecnicos_options = $stmt_tecnicos->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $mensagem = 'Erro ao carregar técnicos: ' . $e->getMessage();
    $tipo_mensagem = 'error';
}

// Obter lista de intervenções com JOIN (Query 2 e Query 3)
$intervencoes = [];
try {
    if ($filtro_tecnico > 0) {
        // Query 3: Intervenções por técnico
        $sql = "SELECT i.*, e.tipo, e.marca, e.modelo, e.endereco_ip, s.nome_sala, t.nome as tecnico_nome 
                FROM intervencoes i 
                JOIN equipamentos e ON i.id_equipamento = e.id_equipamento 
                JOIN salas s ON e.id_sala = s.id_sala 
                JOIN tecnicos t ON i.id_tecnico = t.id_tecnico 
                WHERE i.id_tecnico = :filtro_tecnico 
                ORDER BY i.data_intervencao DESC";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':filtro_tecnico', $filtro_tecnico, PDO::PARAM_INT);
        $stmt->execute();
        $intervencoes = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } else {
        // Query 2: Todas as intervenções
        $sql = "SELECT i.*, e.tipo, e.marca, e.modelo, e.endereco_ip, s.nome_sala, t.nome as tecnico_nome 
                FROM intervencoes i 
                JOIN equipamentos e ON i.id_equipamento = e.id_equipamento 
                JOIN salas s ON e.id_sala = s.id_sala 
                JOIN tecnicos t ON i.id_tecnico = t.id_tecnico 
                ORDER BY i.data_intervencao DESC";
        $stmt = $conn->query($sql);
        $intervencoes = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
} catch (PDOException $e) {
    $mensagem = 'Erro ao carregar intervenções: ' . $e->getMessage();
    $tipo_mensagem = 'error';
}
?>

<h1>Gestão de Intervenções</h1>
<p class="page-subtitle">Registe e consulte o histórico de intervenções técnicas</p>

<?php if ($mensagem): ?>
    <div class="alert alert-<?php echo $tipo_mensagem; ?>">
        <?php echo htmlspecialchars($mensagem); ?>
    </div>
<?php endif; ?>

<!-- Formulário de Inserção -->
<div class="card">
    <h2>Registar Nova Intervenção</h2>
    <form method="POST" action="">
        <input type="hidden" name="acao" value="inserir">
        
        <div class="grid grid-2">
            <div class="form-group">
                <label for="data_intervencao" class="required">Data da Intervenção</label>
                <input type="date" id="data_intervencao" name="data_intervencao" required>
            </div>

            <div class="form-group">
                <label for="id_tecnico" class="required">Técnico Responsável</label>
                <select id="id_tecnico" name="id_tecnico" required>
                    <option value="">-- Selecione um técnico --</option>
                    <?php 
                    if (!empty($tecnicos_options)) {
                        foreach ($tecnicos_options as $tecnico) {
                            echo '<option value="' . $tecnico['id_tecnico'] . '">' . htmlspecialchars($tecnico['nome']) . '</option>';
                        }
                    }
                    ?>
                </select>
            </div>
        </div>

        <div class="form-group">
            <label for="id_equipamento" class="required">Equipamento</label>
            <select id="id_equipamento" name="id_equipamento" required>
                <option value="">-- Selecione um equipamento --</option>
                <?php 
                if (!empty($equipamentos_options)) {
                    foreach ($equipamentos_options as $equip) {
                        $label = htmlspecialchars($equip['tipo'] . ' - ' . $equip['marca'] . ' ' . $equip['modelo'] . ' (' . $equip['endereco_ip'] . ') - Sala: ' . $equip['nome_sala']);
                        echo '<option value="' . $equip['id_equipamento'] . '">' . $label . '</option>';
                    }
                }
                ?>
            </select>
        </div>

        <div class="form-group">
            <label for="descricao" class="required">Descrição da Intervenção</label>
            <textarea id="descricao" name="descricao" placeholder="Descreva a intervenção realizada..." required></textarea>
        </div>

        <div class="card-footer">
            <button type="submit" class="btn btn-primary">Registar Intervenção</button>
            <button type="reset" class="btn btn-secondary">Limpar</button>
        </div>
    </form>
</div>

<!-- Lista de Intervenções -->
<div class="card mt-4">
    <h2>Histórico de Intervenções</h2>
    
    <div class="form-group mb-3">
        <label for="filtro_tecnico">Filtrar por Técnico:</label>
        <select id="filtro_tecnico" onchange="window.location.href = this.value">
            <option value="index.php?page=intervencoes">-- Todos os técnicos --</option>
            <?php 
            if (!empty($tecnicos_options)) {
                foreach ($tecnicos_options as $tecnico) {
                    $selected = ($filtro_tecnico == $tecnico['id_tecnico']) ? 'selected' : '';
                    echo '<option value="index.php?page=intervencoes&tecnico=' . $tecnico['id_tecnico'] . '" ' . $selected . '>' . htmlspecialchars($tecnico['nome']) . '</option>';
                }
            }
            ?>
        </select>
    </div>
    
    <?php if (!empty($intervencoes)): ?>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Data</th>
                    <th>Equipamento</th>
                    <th>Tipo</th>
                    <th>IP</th>
                    <th>Sala</th>
                    <th>Técnico</th>
                    <th>Descrição</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($intervencoes as $row): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['id_intervencao']); ?></td>
                        <td><?php echo date('d/m/Y', strtotime($row['data_intervencao'])); ?></td>
                        <td><?php echo htmlspecialchars($row['marca'] . ' ' . $row['modelo']); ?></td>
                        <td><?php echo htmlspecialchars($row['tipo']); ?></td>
                        <td><code><?php echo htmlspecialchars($row['endereco_ip']); ?></code></td>
                        <td><?php echo htmlspecialchars($row['nome_sala']); ?></td>
                        <td><?php echo htmlspecialchars($row['tecnico_nome']); ?></td>
                        <td><?php echo htmlspecialchars(substr($row['descricao'], 0, 50)) . (strlen($row['descricao']) > 50 ? '...' : ''); ?></td>
                        <td>
                            <div class="table-actions">
                                <a href="index.php?page=intervencoes&eliminar=<?php echo $row['id_intervencao']; ?>" 
                                   class="btn btn-danger btn-small" 
                                   onclick="return confirm('Tem a certeza que deseja eliminar esta intervenção?');">
                                   Eliminar
                                </a>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <div class="no-data">
            <p>Nenhuma intervenção registada. Comece por registar uma nova intervenção.</p>
        </div>
    <?php endif; ?>
</div>
