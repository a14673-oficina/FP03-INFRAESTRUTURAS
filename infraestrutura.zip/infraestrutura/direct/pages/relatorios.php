<?php
/**
 * Página de Relatórios e Estatísticas
 * Dashboard com informações detalhadas sobre equipamentos, técnicos e intervenções
 */

require_once __DIR__ . '/../config/ligacao.php';

// ============================================
// COLETA DE DADOS
// ============================================

// Estatísticas Gerais
$stats = [];
try {
    $result = $conn->query("SELECT COUNT(*) as total FROM salas");
    $stats['salas'] = $result->fetch(PDO::FETCH_ASSOC)['total'];

    $result = $conn->query("SELECT COUNT(*) as total FROM equipamentos");
    $stats['equipamentos'] = $result->fetch(PDO::FETCH_ASSOC)['total'];

    $result = $conn->query("SELECT COUNT(*) as total FROM tecnicos");
    $stats['tecnicos'] = $result->fetch(PDO::FETCH_ASSOC)['total'];

    $result = $conn->query("SELECT COUNT(*) as total FROM intervencoes");
    $stats['intervencoes'] = $result->fetch(PDO::FETCH_ASSOC)['total'];

    $result = $conn->query("
        SELECT COUNT(*) as total FROM equipamentos e 
        LEFT JOIN intervencoes i ON e.id_equipamento = i.id_equipamento 
        WHERE i.id_intervencao IS NULL
    ");
    $stats['sem_intervencoes'] = $result->fetch(PDO::FETCH_ASSOC)['total'];
    $stats['com_intervencoes'] = $stats['equipamentos'] - $stats['sem_intervencoes'];

    // Equipamentos por Sala
    $equipamentos_por_sala = [];
    $result = $conn->query("
        SELECT s.nome_sala, COUNT(e.id_equipamento) as total 
        FROM salas s 
        LEFT JOIN equipamentos e ON s.id_sala = e.id_sala 
        GROUP BY s.id_sala, s.nome_sala 
        ORDER BY total DESC
    ");
    $equipamentos_por_sala = $result->fetchAll(PDO::FETCH_ASSOC);

    // Intervenções por Técnico
    $intervencoes_por_tecnico = [];
    $result = $conn->query("
        SELECT t.nome, COUNT(i.id_intervencao) as total 
        FROM tecnicos t 
        LEFT JOIN intervencoes i ON t.id_tecnico = i.id_tecnico 
        GROUP BY t.id_tecnico, t.nome 
        ORDER BY total DESC
    ");
    $intervencoes_por_tecnico = $result->fetchAll(PDO::FETCH_ASSOC);

    // Tipos de Equipamentos
    $tipos_equipamentos = [];
    $result = $conn->query("
        SELECT tipo, COUNT(*) as total 
        FROM equipamentos 
        GROUP BY tipo 
        ORDER BY total DESC
    ");
    $tipos_equipamentos = $result->fetchAll(PDO::FETCH_ASSOC);

    // Intervenções por Mês
    $intervencoes_por_mes = [];
    $result = $conn->query("
        SELECT DATE_FORMAT(data_intervencao, '%Y-%m') as mes, COUNT(*) as total 
        FROM intervencoes 
        GROUP BY DATE_FORMAT(data_intervencao, '%Y-%m') 
        ORDER BY mes DESC 
        LIMIT 12
    ");
    $intervencoes_por_mes = $result->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    $mensagem = 'Erro ao carregar dados do relatório: ' . $e->getMessage();
    $tipo_mensagem = 'error';
}
?>

<!-- ============================================ -->
<!-- CABEÇALHO -->
<!-- ============================================ -->
<div class="report-header">
    <h1>Relatórios e Estatísticas</h1>
    <p class="page-subtitle">Dashboard com informações detalhadas sobre a infraestrutura de rede</p>
</div>

<?php if (isset($mensagem) && $mensagem): ?>
    <div class="alert alert-<?php echo $tipo_mensagem; ?>">
        <?php echo htmlspecialchars($mensagem); ?>
    </div>
<?php endif; ?>

<!-- ============================================ -->
<!-- SEÇÃO 1: ESTATÍSTICAS PRINCIPAIS -->
<!-- ============================================ -->
<section class="report-section">
    <div class="grid grid-5">
        <!-- Card: Salas -->
        <div class="stat-card">
            <div class="stat-icon">
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
                    <polyline points="9 22 9 12 15 12 15 22"></polyline>
                </svg>
            </div>
            <div class="stat-number"><?php echo $stats['salas'] ?? 0; ?></div>
            <div class="stat-label">Salas</div>
        </div>

        <!-- Card: Equipamentos -->
        <div class="stat-card">
            <div class="stat-icon">
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                    <rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect>
                    <line x1="2" y1="20" x2="22" y2="20"></line>
                </svg>
            </div>
            <div class="stat-number"><?php echo $stats['equipamentos'] ?? 0; ?></div>
            <div class="stat-label">Equipamentos</div>
        </div>

        <!-- Card: Técnicos -->
        <div class="stat-card">
            <div class="stat-icon">
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                    <circle cx="12" cy="7" r="4"></circle>
                </svg>
            </div>
            <div class="stat-number"><?php echo $stats['tecnicos'] ?? 0; ?></div>
            <div class="stat-label">Técnicos</div>
        </div>

        <!-- Card: Intervenções -->
        <div class="stat-card">
            <div class="stat-icon">
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 1 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"></path>
                </svg>
            </div>
            <div class="stat-number"><?php echo $stats['intervencoes'] ?? 0; ?></div>
            <div class="stat-label">Intervenções</div>
        </div>

        <!-- Card: Sem Intervenção -->
        <div class="stat-card">
            <div class="stat-icon">
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3.05h16.94a2 2 0 0 0 1.71-3.05L13.71 3.86a2 2 0 0 0-3.42 0z"></path>
                    <line x1="12" y1="9" x2="12" y2="13"></line>
                    <line x1="12" y1="17" x2="12.01" y2="17"></line>
                </svg>
            </div>
            <div class="stat-number"><?php echo $stats['sem_intervencoes'] ?? 0; ?></div>
            <div class="stat-label">Sem Intervenção</div>
        </div>
    </div>
</section>

<!-- ============================================ -->
<!-- SEÇÃO 2: ANÁLISE POR SALA E TÉCNICO -->
<!-- ============================================ -->
<section class="report-section">
    <div class="grid grid-2">
        <!-- Equipamentos por Sala -->
        <div class="card">
            <h2>Equipamentos por Sala</h2>
            <?php if (!empty($equipamentos_por_sala)): ?>
                <table>
                    <thead>
                        <tr>
                            <th>Sala</th>
                            <th>Quantidade</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($equipamentos_por_sala as $row): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['nome_sala']); ?></td>
                                <td><strong><?php echo $row['total']; ?></strong></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p class="empty-state">Nenhum dado disponível.</p>
            <?php endif; ?>
        </div>

        <!-- Intervenções por Técnico -->
        <div class="card">
            <h2>Intervenções por Técnico</h2>
            <?php if (!empty($intervencoes_por_tecnico)): ?>
                <table>
                    <thead>
                        <tr>
                            <th>Técnico</th>
                            <th>Intervenções</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($intervencoes_por_tecnico as $row): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['nome']); ?></td>
                                <td><strong><?php echo $row['total']; ?></strong></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p class="empty-state">Nenhum dado disponível.</p>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- ============================================ -->
<!-- SEÇÃO 3: DISTRIBUIÇÃO DE TIPOS -->
<!-- ============================================ -->
<section class="report-section">
    <div class="card">
        <h2>Distribuição de Tipos de Equipamentos</h2>
        <?php if (!empty($tipos_equipamentos)): ?>
            <table>
                <thead>
                    <tr>
                        <th>Tipo</th>
                        <th>Quantidade</th>
                        <th>Percentagem</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($tipos_equipamentos as $row): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['tipo']); ?></td>
                            <td><?php echo $row['total']; ?></td>
                            <td>
                                <div class="percentage-bar">
                                    <?php 
                                        $percentage = 0;
                                        if (($stats['equipamentos'] ?? 0) > 0) {
                                            $percentage = round(($row['total'] / $stats['equipamentos']) * 100, 1);
                                        }
                                    ?>
                                    <div class="percentage-fill" style="width: <?php echo $percentage; ?>%"></div>
                                    <span class="percentage-text"><?php echo $percentage; ?>%</span>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p class="empty-state">Nenhum equipamento registado.</p>
        <?php endif; ?>
    </div>
</section>

<!-- ============================================ -->
<!-- SEÇÃO 4: RESUMO DE INTERVENÇÕES -->
<!-- ============================================ -->
<section class="report-section">
    <div class="card">
        <h2>Resumo de Intervenções</h2>
        <div class="grid grid-3">
            <div class="summary-box">
                <div class="summary-label">Total de Intervenções</div>
                <div class="summary-value"><?php echo $stats['intervencoes'] ?? 0; ?></div>
            </div>
            <div class="summary-box">
                <div class="summary-label">Equipamentos com Intervenção</div>
                <div class="summary-value"><?php echo $stats['com_intervencoes'] ?? 0; ?></div>
            </div>
            <div class="summary-box">
                <div class="summary-label">Equipamentos sem Intervenção</div>
                <div class="summary-value"><?php echo $stats['sem_intervencoes'] ?? 0; ?></div>
            </div>
        </div>

        <?php if (!empty($intervencoes_por_mes)): ?>
            <h3>Intervenções por Mês (Últimos 12 meses)</h3>
            <table>
                <thead>
                    <tr>
                        <th>Mês/Ano</th>
                        <th>Quantidade</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($intervencoes_por_mes as $row): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['mes']); ?></td>
                            <td><?php echo $row['total']; ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p class="empty-state">Nenhuma intervenção registada nos últimos 12 meses.</p>
        <?php endif; ?>
    </div>
</section>

<!-- ============================================ -->
<!-- BOTÕES DE AÇÃO -->
<!-- ============================================ -->
<div class="report-actions">
    <button onclick="window.print()" class="btn btn-secondary">Imprimir Relatório</button>
    <button onclick="exportarCSV()" class="btn btn-secondary">Exportar para CSV</button>
</div>

<style>
    /* Estilos para o layout do relatório */
    .report-header { text-align: center; margin-bottom: 2rem; }
    .report-header h1 { font-size: 2.5rem; color: #333; margin-bottom: 0.5rem; }
    .report-header .page-subtitle { color: #666; font-size: 1.1rem; }
    .report-section { margin-bottom: 3rem; }
    .grid-5 { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 1.5rem; }
    .stat-card { background: #fff; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.05); padding: 1.5rem; text-align: center; display: flex; flex-direction: column; align-items: center; justify-content: center; }
    .stat-card .stat-icon { color: #0071e3; margin-bottom: 0.75rem; }
    .stat-card .stat-number { font-size: 2.2rem; font-weight: 700; color: #1c1c1e; margin-bottom: 0.25rem; }
    .stat-card .stat-label { font-size: 0.9rem; color: #666; text-transform: uppercase; letter-spacing: 0.5px; }
    .grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem; }
    .card { background: #fff; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.05); padding: 2rem; }
    .card h2 { font-size: 1.5rem; color: #1c1c1e; margin-bottom: 1.5rem; border-bottom: 1px solid #eee; padding-bottom: 1rem; }
    table { width: 100%; border-collapse: collapse; margin-top: 1rem; }
    table th, table td { padding: 12px 15px; border-bottom: 1px solid #eee; text-align: left; }
    table th { background-color: #f8f8f8; font-weight: 600; color: #333; text-transform: uppercase; font-size: 0.85rem; }
    .percentage-bar { background-color: #e0e0e0; border-radius: 4px; height: 20px; width: 100%; overflow: hidden; position: relative; }
    .percentage-fill { background-color: #0071e3; height: 100%; border-radius: 4px; display: flex; align-items: center; justify-content: flex-end; padding-right: 5px; box-sizing: border-box; }
    .percentage-text { position: absolute; right: 5px; color: #333; font-size: 0.8rem; font-weight: 600; }
    .summary-box { background: #f0f0f0; border-radius: 8px; padding: 1rem; text-align: center; }
    .summary-box .summary-label { font-size: 0.9rem; color: #555; margin-bottom: 0.5rem; }
    .summary-box .summary-value { font-size: 1.8rem; font-weight: 700; color: #1c1c1e; }
    .report-actions { text-align: center; margin-top: 3rem; }
    .report-actions .btn { margin: 0 0.5rem; padding: 0.8rem 1.5rem; font-size: 1rem; border-radius: 8px; cursor: pointer; }
    .btn-secondary { background-color: #e0e0e0; color: #333; border: none; }
</style>

<script>
    function exportarCSV() {
        let csv = [];
        let rows = document.querySelectorAll("table tr");
        for (let i = 0; i < rows.length; i++) {
            let row = [], cols = rows[i].querySelectorAll("td, th");
            for (let j = 0; j < cols.length; j++) {
                let data = cols[j].innerText.replace(/\n/g, ' ').trim();
                row.push(data);
            }
            csv.push(row.join(';'));
        }
        let csvFile = new Blob([csv.join('\n')], { type: 'text/csv;charset=utf-8;' });
        let downloadLink = document.createElement('a');
        downloadLink.download = 'relatorio_infraestrutura.csv';
        downloadLink.href = window.URL.createObjectURL(csvFile);
        downloadLink.click();
    }
</script>
