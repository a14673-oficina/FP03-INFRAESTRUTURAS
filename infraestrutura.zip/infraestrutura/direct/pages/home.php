<?php
/**
 * Página Inicial - Dashboard
 */
?>
<div class="card">
    <h1>Bem-vindo ao Sistema de Gestão da Rede OFICINA</h1>
    <p class="page-subtitle">Gerencie a infraestrutura da rede de forma eficiente e organizada</p>
</div>

<div class="grid grid-3">
    <div class="card">
        <h3>Gestão de Salas</h3>
        <p>Organize e controle todas as salas onde estão instalados os equipamentos de rede.</p>
        <p style="margin-top: 1rem;">
            <a href="index.php?page=salas" class="btn btn-primary">Gerir Salas</a>
        </p>
    </div>

    <div class="card">
        <h3>Gestão de Equipamentos</h3>
        <p>Cadastre e consulte todos os equipamentos de rede (routers, switches, access points).</p>
        <p style="margin-top: 1rem;">
            <a href="index.php?page=equipamentos" class="btn btn-primary">Gerir Equipamentos</a>
        </p>
    </div>

    <div class="card">
        <h3>Gestão de Técnicos</h3>
        <p>Mantenha um registo de todos os técnicos responsáveis pelas intervenções.</p>
        <p style="margin-top: 1rem;">
            <a href="index.php?page=tecnicos" class="btn btn-primary">Gerir Técnicos</a>
        </p>
    </div>

    <div class="card">
        <h3>Registo de Intervenções</h3>
        <p>Registe e consulte o histórico de todas as intervenções técnicas realizadas.</p>
        <p style="margin-top: 1rem;">
            <a href="index.php?page=intervencoes" class="btn btn-primary">Gerir Intervenções</a>
        </p>
    </div>

    <div class="card">
        <h3>Equipamentos sem Intervenções</h3>
        <p>Consulte os equipamentos que nunca tiveram intervenção técnica registada.</p>
        <p style="margin-top: 1rem;">
            <a href="index.php?page=equipamentos_sem_intervencoes" class="btn btn-primary">Ver Lista</a>
        </p>
    </div>

    <div class="card">
        <h3>Relatórios</h3>
        <p>Consulte informações detalhadas sobre equipamentos, técnicos e intervenções.</p>
        <p style="margin-top: 1rem;">
            <a href="index.php?page=relatorios" class="btn btn-primary">Ver Relatórios</a>
        </p>
    </div>
</div>

<div class="card mt-4">
    <h2>Funcionalidades do Sistema</h2>
    <p>Este sistema permite:</p>
    <ul style="margin-left: 2rem; margin-top: 1rem;">
        <li><strong>Gestão de Salas:</strong> Listar e inserir salas com localização</li>
        <li><strong>Gestão de Equipamentos:</strong> Cadastrar equipamentos com tipo, marca, modelo, IP e sala associada</li>
        <li><strong>Gestão de Técnicos:</strong> Manter registo de técnicos com contacto</li>
        <li><strong>Registo de Intervenções:</strong> Registar intervenções com data, descrição, equipamento e técnico responsável</li>
        <li><strong>Consultas Avançadas:</strong> Equipamentos por sala, intervenções por equipamento/técnico, equipamentos sem intervenções</li>
    </ul>
</div>

<div class="card mt-4">
    <h2>Instruções de Uso</h2>
    <p>Para começar, utilize o menu de navegação no topo da página para aceder às diferentes secções do sistema:</p>
    <ol style="margin-left: 2rem; margin-top: 1rem;">
        <li>Comece por criar as <strong>Salas</strong> onde os equipamentos serão instalados</li>
        <li>Adicione os <strong>Equipamentos</strong> associando-os às salas criadas</li>
        <li>Registe os <strong>Técnicos</strong> responsáveis pelas manutenções</li>
        <li>Crie <strong>Intervenções</strong> ligando equipamentos e técnicos</li>
        <li>Consulte os relatórios e análises disponíveis</li>
    </ol>
</div>
