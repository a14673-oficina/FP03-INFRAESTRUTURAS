<?php
/**
 * Página de Gestão de Técnicos
 */
require_once __DIR__ . 
'/../config/ligacao.php';

$mensagem = '';
$tipo_mensagem = '';

// Processar formulário de inserção
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao']) && $_POST['acao'] === 'inserir') {
    $nome = trim($_POST['nome'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $contacto = trim($_POST['contacto'] ?? '');

    // Validação
    if (empty($nome) || empty($email) || empty($contacto)) {
        $mensagem = 'Por favor, preencha todos os campos obrigatórios.';
        $tipo_mensagem = 'error';
    } else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $mensagem = 'Endereço de email inválido.';
        $tipo_mensagem = 'error';
    } else {
        try {
            // Inserir na base de dados usando PDO
            $sql = "INSERT INTO tecnicos (nome, email, contacto) VALUES (:nome, :email, :contacto)";
            $stmt = $conn->prepare($sql);
            $stmt->bindParam(':nome', $nome);
            $stmt->bindParam(':email', $email);
            $stmt->bindParam(':contacto', $contacto);
            
            if ($stmt->execute()) {
                $mensagem = 'Técnico inserido com sucesso!';
                $tipo_mensagem = 'success';
                $_POST = array();
            } else {
                $errorInfo = $stmt->errorInfo();
                if ($errorInfo[1] == 1062) { // Código de erro para entrada duplicada
                    $mensagem = 'Este email já está registado no sistema.';
                } else {
                    $mensagem = 'Erro ao inserir técnico: ' . $errorInfo[2];
                }
                $tipo_mensagem = 'error';
            }
        } catch (PDOException $e) {
            $mensagem = 'Erro na base de dados: ' . $e->getMessage();
            $tipo_mensagem = 'error';
        }
    }
}

// Processar eliminação
if (isset($_GET['eliminar'])) {
    $id_tecnico = intval($_GET['eliminar']);
    
    try {
        // Verificar se existem intervenções associadas
        $sql_check = "SELECT COUNT(*) as count FROM intervencoes WHERE id_tecnico = :id_tecnico";
        $stmt_check = $conn->prepare($sql_check);
        $stmt_check->bindParam(':id_tecnico', $id_tecnico, PDO::PARAM_INT);
        $stmt_check->execute();
        $row_check = $stmt_check->fetch(PDO::FETCH_ASSOC);
        
        if ($row_check['count'] > 0) {
            $mensagem = 'Não é possível eliminar este técnico porque existem intervenções associadas.';
            $tipo_mensagem = 'error';
        } else {
            $sql_delete = "DELETE FROM tecnicos WHERE id_tecnico = :id_tecnico";
            $stmt_delete = $conn->prepare($sql_delete);
            $stmt_delete->bindParam(':id_tecnico', $id_tecnico, PDO::PARAM_INT);
            
            if ($stmt_delete->execute()) {
                $mensagem = 'Técnico eliminado com sucesso!';
                $tipo_mensagem = 'success';
            } else {
                $mensagem = 'Erro ao eliminar técnico: ' . implode(' - ', $stmt_delete->errorInfo());
                $tipo_mensagem = 'error';
            }
        }
    } catch (PDOException $e) {
        $mensagem = 'Erro na base de dados: ' . $e->getMessage();
        $tipo_mensagem = 'error';
    }
}

// Obter lista de técnicos
$tecnicos = [];
try {
    $sql = "SELECT * FROM tecnicos ORDER BY nome ASC";
    $stmt = $conn->query($sql);
    $tecnicos = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $mensagem = 'Erro ao carregar técnicos: ' . $e->getMessage();
    $tipo_mensagem = 'error';
}
?>

<h1>Gestão de Técnicos</h1>
<p class="page-subtitle">Gerencie os técnicos responsáveis pelas intervenções na rede</p>

<?php if ($mensagem): ?>
    <div class="alert alert-<?php echo $tipo_mensagem; ?>">
        <?php echo htmlspecialchars($mensagem); ?>
    </div>
<?php endif; ?>

<!-- Formulário de Inserção -->
<div class="card">
    <h2>Adicionar Novo Técnico</h2>
    <form method="POST" action="">
        <input type="hidden" name="acao" value="inserir">
        
        <div class="form-group">
            <label for="nome" class="required">Nome Completo</label>
            <input type="text" id="nome" name="nome" placeholder="Ex: João Silva" required>
        </div>

        <div class="grid grid-2">
            <div class="form-group">
                <label for="email" class="required">Email</label>
                <input type="email" id="email" name="email" placeholder="Ex: joao@escola.pt" required>
            </div>

            <div class="form-group">
                <label for="contacto" class="required">Contacto (Telefone)</label>
                <input type="tel" id="contacto" name="contacto" placeholder="Ex: 912345678" required>
            </div>
        </div>

        <div class="card-footer">
            <button type="submit" class="btn btn-primary">Adicionar Técnico</button>
            <button type="reset" class="btn btn-secondary">Limpar</button>
        </div>
    </form>
</div>

<!-- Lista de Técnicos -->
<div class="card mt-4">
    <h2>Lista de Técnicos</h2>
    
    <?php if (!empty($tecnicos)): ?>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nome</th>
                    <th>Email</th>
                    <th>Contacto</th>
                    <th>Data de Criação</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($tecnicos as $row): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['id_tecnico']); ?></td>
                        <td><?php echo htmlspecialchars($row['nome']); ?></td>
                        <td><?php echo htmlspecialchars($row['email']); ?></td>
                        <td><?php echo htmlspecialchars($row['contacto']); ?></td>
                        <td><?php echo date('d/m/Y H:i', strtotime($row['data_criacao'])); ?></td>
                        <td>
                            <div class="table-actions">
                                <a href="index.php?page=tecnicos&eliminar=<?php echo $row['id_tecnico']; ?>" 
                                   class="btn btn-danger btn-small" 
                                   onclick="return confirm('Tem a certeza que deseja eliminar este técnico?');">
                                   Eliminar
                                </a>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <div class="no-data">
            <p>Nenhum técnico registado. Comece por adicionar um novo técnico.</p>
        </div>
    <?php endif; ?>
</div>
