<?php
/**
 * Página de Gestão de Equipamentos
 */
require_once __DIR__ . 
'/../config/ligacao.php';

$mensagem = '';
$tipo_mensagem = '';

// Processar formulário de inserção
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao']) && $_POST['acao'] === 'inserir') {
    $tipo = trim($_POST['tipo'] ?? '');
    $marca = trim($_POST['marca'] ?? '');
    $modelo = trim($_POST['modelo'] ?? '');
    $endereco_ip = trim($_POST['endereco_ip'] ?? '');
    $id_sala = intval($_POST['id_sala'] ?? 0);

    // Validação
    if (empty($tipo) || empty($marca) || empty($modelo) || empty($endereco_ip) || $id_sala <= 0) {
        $mensagem = 'Por favor, preencha todos os campos obrigatórios.';
        $tipo_mensagem = 'error';
    } else if (!filter_var($endereco_ip, FILTER_VALIDATE_IP)) {
        $mensagem = 'Endereço IP inválido. Por favor, insira um IP válido.';
        $tipo_mensagem = 'error';
    } else {
        try {
            // Inserir na base de dados usando PDO
            $sql = "INSERT INTO equipamentos (tipo, marca, modelo, endereco_ip, id_sala) VALUES (:tipo, :marca, :modelo, :endereco_ip, :id_sala)";
            $stmt = $conn->prepare($sql);
            $stmt->bindParam(':tipo', $tipo);
            $stmt->bindParam(':marca', $marca);
            $stmt->bindParam(':modelo', $modelo);
            $stmt->bindParam(':endereco_ip', $endereco_ip);
            $stmt->bindParam(':id_sala', $id_sala, PDO::PARAM_INT);
            
            if ($stmt->execute()) {
                $mensagem = 'Equipamento inserido com sucesso!';
                $tipo_mensagem = 'success';
                $_POST = array();
            } else {
                $errorInfo = $stmt->errorInfo();
                if ($errorInfo[1] == 1062) { // Código de erro para entrada duplicada
                    $mensagem = 'Este endereço IP já está registado no sistema.';
                } else {
                    $mensagem = 'Erro ao inserir equipamento: ' . $errorInfo[2];
                }
                $tipo_mensagem = 'error';
            }
        } catch (PDOException $e) {
            $mensagem = 'Erro na base de dados: ' . $e->getMessage();
            $tipo_mensagem = 'error';
        }
    }
}

// Processar eliminação
if (isset($_GET['eliminar'])) {
    $id_equipamento = intval($_GET['eliminar']);
    
    try {
        // Verificar se existem intervenções associadas
        $sql_check = "SELECT COUNT(*) as count FROM intervencoes WHERE id_equipamento = :id_equipamento";
        $stmt_check = $conn->prepare($sql_check);
        $stmt_check->bindParam(':id_equipamento', $id_equipamento, PDO::PARAM_INT);
        $stmt_check->execute();
        $row_check = $stmt_check->fetch(PDO::FETCH_ASSOC);
        
        if ($row_check['count'] > 0) {
            $mensagem = 'Não é possível eliminar este equipamento porque existem intervenções associadas.';
            $tipo_mensagem = 'error';
        } else {
            $sql_delete = "DELETE FROM equipamentos WHERE id_equipamento = :id_equipamento";
            $stmt_delete = $conn->prepare($sql_delete);
            $stmt_delete->bindParam(':id_equipamento', $id_equipamento, PDO::PARAM_INT);
            
            if ($stmt_delete->execute()) {
                $mensagem = 'Equipamento eliminado com sucesso!';
                $tipo_mensagem = 'success';
            } else {
                $mensagem = 'Erro ao eliminar equipamento: ' . implode(' - ', $stmt_delete->errorInfo());
                $tipo_mensagem = 'error';
            }
        }
    } catch (PDOException $e) {
        $mensagem = 'Erro na base de dados: ' . $e->getMessage();
        $tipo_mensagem = 'error';
    }
}

// Filtro por sala
$filtro_sala = isset($_GET['sala']) ? intval($_GET['sala']) : 0;

// Obter lista de salas para o formulário e filtro
$salas_options = [];
try {
    $sql_salas = "SELECT id_sala, nome_sala FROM salas ORDER BY nome_sala ASC";
    $stmt_salas = $conn->query($sql_salas);
    $salas_options = $stmt_salas->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $mensagem = 'Erro ao carregar salas: ' . $e->getMessage();
    $tipo_mensagem = 'error';
}

// Obter lista de equipamentos
$equipamentos = [];
try {
    if ($filtro_sala > 0) {
        $sql = "SELECT e.*, s.nome_sala FROM equipamentos e 
                LEFT JOIN salas s ON e.id_sala = s.id_sala 
                WHERE e.id_sala = :filtro_sala 
                ORDER BY e.tipo ASC";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':filtro_sala', $filtro_sala, PDO::PARAM_INT);
        $stmt->execute();
        $equipamentos = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } else {
        $sql = "SELECT e.*, s.nome_sala FROM equipamentos e 
                LEFT JOIN salas s ON e.id_sala = s.id_sala 
                ORDER BY e.tipo ASC";
        $stmt = $conn->query($sql);
        $equipamentos = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
} catch (PDOException $e) {
    $mensagem = 'Erro ao carregar equipamentos: ' . $e->getMessage();
    $tipo_mensagem = 'error';
}
?>

<h1>Gestão de Equipamentos</h1>
<p class="page-subtitle">Gerencie os equipamentos de rede (routers, switches, access points, etc.)</p>

<?php if ($mensagem): ?>
    <div class="alert alert-<?php echo $tipo_mensagem; ?>">
        <?php echo htmlspecialchars($mensagem); ?>
    </div>
<?php endif; ?>

<!-- Formulário de Inserção -->
<div class="card">
    <h2>Adicionar Novo Equipamento</h2>
    <form method="POST" action="">
        <input type="hidden" name="acao" value="inserir">
        
        <div class="grid grid-2">
            <div class="form-group">
                <label for="tipo" class="required">Tipo de Equipamento</label>
                <select id="tipo" name="tipo" required>
                    <option value="">-- Selecione um tipo --</option>
                    <option value="Router">Router</option>
                    <option value="Switch">Switch</option>
                    <option value="Access Point">Access Point</option>
                    <option value="Firewall">Firewall</option>
                    <option value="Outro">Outro</option>
                </select>
            </div>

            <div class="form-group">
                <label for="marca" class="required">Marca</label>
                <input type="text" id="marca" name="marca" placeholder="Ex: Cisco, TP-Link, Ubiquiti" required>
            </div>
        </div>

        <div class="grid grid-2">
            <div class="form-group">
                <label for="modelo" class="required">Modelo</label>
                <input type="text" id="modelo" name="modelo" placeholder="Ex: WR840N" required>
            </div>

            <div class="form-group">
                <label for="endereco_ip" class="required">Endereço IP</label>
                <input type="text" id="endereco_ip" name="endereco_ip" placeholder="Ex: 192.168.1.1" required>
            </div>
        </div>

        <div class="form-group">
            <label for="id_sala" class="required">Sala</label>
            <select id="id_sala" name="id_sala" required>
                <option value="">-- Selecione uma sala --</option>
                <?php 
                if (!empty($salas_options)) {
                    foreach ($salas_options as $sala) {
                        echo '<option value="' . $sala['id_sala'] . '">' . htmlspecialchars($sala['nome_sala']) . '</option>';
                    }
                }
                ?>
            </select>
        </div>

        <div class="card-footer">
            <button type="submit" class="btn btn-primary">Adicionar Equipamento</button>
            <button type="reset" class="btn btn-secondary">Limpar</button>
        </div>
    </form>
</div>

<!-- Lista de Equipamentos -->
<div class="card mt-4">
    <h2>Lista de Equipamentos</h2>
    
    <div class="form-group mb-3">
        <label for="filtro_sala">Filtrar por Sala:</label>
        <select id="filtro_sala" onchange="window.location.href = this.value">
            <option value="index.php?page=equipamentos">-- Todas as salas --</option>
            <?php 
            if (!empty($salas_options)) {
                foreach ($salas_options as $sala) {
                    $selected = ($filtro_sala == $sala['id_sala']) ? 'selected' : '';
                    echo '<option value="index.php?page=equipamentos&sala=' . $sala['id_sala'] . '" ' . $selected . '>' . htmlspecialchars($sala['nome_sala']) . '</option>';
                }
            }
            ?>
        </select>
    </div>
    
    <?php if (!empty($equipamentos)): ?>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Tipo</th>
                    <th>Marca</th>
                    <th>Modelo</th>
                    <th>Endereço IP</th>
                    <th>Sala</th>
                    <th>Data de Criação</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($equipamentos as $row): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['id_equipamento']); ?></td>
                        <td><?php echo htmlspecialchars($row['tipo']); ?></td>
                        <td><?php echo htmlspecialchars($row['marca']); ?></td>
                        <td><?php echo htmlspecialchars($row['modelo']); ?></td>
                        <td><code><?php echo htmlspecialchars($row['endereco_ip']); ?></code></td>
                        <td><?php echo htmlspecialchars($row['nome_sala']); ?></td>
                        <td><?php echo date('d/m/Y H:i', strtotime($row['data_criacao'])); ?></td>
                        <td>
                            <div class="table-actions">
                                <a href="index.php?page=equipamentos&eliminar=<?php echo $row['id_equipamento']; ?>" 
                                   class="btn btn-danger btn-small" 
                                   onclick="return confirm('Tem a certeza que deseja eliminar este equipamento?');">
                                   Eliminar
                                </a>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <div class="no-data">
            <p>Nenhum equipamento registado. Comece por adicionar um novo equipamento.</p>
        </div>
    <?php endif; ?>
</div>
