<?php
/**
 * Página de Gestão de Salas
 */
require_once __DIR__ . 
'/../config/ligacao.php';

$mensagem = '';
$tipo_mensagem = '';

// Processar formulário de inserção
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao']) && $_POST['acao'] === 'inserir') {
    $nome_sala = trim($_POST['nome_sala'] ?? '');
    $localizacao = trim($_POST['localizacao'] ?? '');

    // Validação
    if (empty($nome_sala) || empty($localizacao)) {
        $mensagem = 'Por favor, preencha todos os campos obrigatórios.';
        $tipo_mensagem = 'error';
    } else {
        try {
            // Inserir na base de dados usando PDO
            $sql = "INSERT INTO salas (nome_sala, localizacao) VALUES (:nome_sala, :localizacao)";
            $stmt = $conn->prepare($sql);
            $stmt->bindParam(':nome_sala', $nome_sala);
            $stmt->bindParam(':localizacao', $localizacao);
            
            if ($stmt->execute()) {
                $mensagem = 'Sala inserida com sucesso!';
                $tipo_mensagem = 'success';
                // Limpar formulário
                $_POST = array();
            } else {
                $mensagem = 'Erro ao inserir sala: ' . implode(' - ', $stmt->errorInfo());
                $tipo_mensagem = 'error';
            }
        } catch (PDOException $e) {
            $mensagem = 'Erro na base de dados: ' . $e->getMessage();
            $tipo_mensagem = 'error';
        }
    }
}

// Processar eliminação
if (isset($_GET['eliminar'])) {
    $id_sala = intval($_GET['eliminar']);
    
    try {
        // Verificar se existem equipamentos associados
        $sql_check = "SELECT COUNT(*) as count FROM equipamentos WHERE id_sala = :id_sala";
        $stmt_check = $conn->prepare($sql_check);
        $stmt_check->bindParam(':id_sala', $id_sala);
        $stmt_check->execute();
        $row_check = $stmt_check->fetch(PDO::FETCH_ASSOC);
        
        if ($row_check['count'] > 0) {
            $mensagem = 'Não é possível eliminar esta sala porque existem equipamentos associados.';
            $tipo_mensagem = 'error';
        } else {
            $sql_delete = "DELETE FROM salas WHERE id_sala = :id_sala";
            $stmt_delete = $conn->prepare($sql_delete);
            $stmt_delete->bindParam(':id_sala', $id_sala);
            
            if ($stmt_delete->execute()) {
                $mensagem = 'Sala eliminada com sucesso!';
                $tipo_mensagem = 'success';
            } else {
                $mensagem = 'Erro ao eliminar sala: ' . implode(' - ', $stmt_delete->errorInfo());
                $tipo_mensagem = 'error';
            }
        }
    } catch (PDOException $e) {
        $mensagem = 'Erro na base de dados: ' . $e->getMessage();
        $tipo_mensagem = 'error';
    }
}

// Obter lista de salas
$salas = [];
try {
    $sql = "SELECT * FROM salas ORDER BY nome_sala ASC";
    $stmt = $conn->query($sql);
    $salas = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $mensagem = 'Erro ao carregar salas: ' . $e->getMessage();
    $tipo_mensagem = 'error';
}
?>

<h1>Gestão de Salas</h1>
<p class="page-subtitle">Gerencie as salas onde estão instalados os equipamentos de rede</p>

<?php if ($mensagem): ?>
    <div class="alert alert-<?php echo $tipo_mensagem; ?>">
        <?php echo htmlspecialchars($mensagem); ?>
    </div>
<?php endif; ?>

<!-- Formulário de Inserção -->
<div class="card">
    <h2>Adicionar Nova Sala</h2>
    <form method="POST" action="">
        <input type="hidden" name="acao" value="inserir">
        
        <div class="form-group">
            <label for="nome_sala" class="required">Nome da Sala</label>
            <input type="text" id="nome_sala" name="nome_sala" placeholder="Ex: Sala de Informática 1" required>
        </div>

        <div class="form-group">
            <label for="localizacao" class="required">Localização</label>
            <input type="text" id="localizacao" name="localizacao" placeholder="Ex: Piso 1, Bloco A" required>
        </div>

        <div class="card-footer">
            <button type="submit" class="btn btn-primary">Adicionar Sala</button>
            <button type="reset" class="btn btn-secondary">Limpar</button>
        </div>
    </form>
</div>

<!-- Lista de Salas -->
<div class="card mt-4">
    <h2>Lista de Salas</h2>
    
    <?php if (!empty($salas)): ?>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nome da Sala</th>
                    <th>Localização</th>
                    <th>Data de Criação</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($salas as $row): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['id_sala']); ?></td>
                        <td><?php echo htmlspecialchars($row['nome_sala']); ?></td>
                        <td><?php echo htmlspecialchars($row['localizacao']); ?></td>
                        <td><?php echo date('d/m/Y H:i', strtotime($row['data_criacao'])); ?></td>
                        <td>
                            <div class="table-actions">
                                <a href="index.php?page=salas&eliminar=<?php echo $row['id_sala']; ?>" 
                                   class="btn btn-danger btn-small" 
                                   onclick="return confirm('Tem a certeza que deseja eliminar esta sala?');">
                                   Eliminar
                                </a>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <div class="no-data">
            <p>Nenhuma sala registada. Comece por adicionar uma nova sala.</p>
        </div>
    <?php endif; ?>
</div>
