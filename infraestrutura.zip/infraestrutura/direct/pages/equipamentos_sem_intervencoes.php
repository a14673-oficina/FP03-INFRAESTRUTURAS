<?php
/**
 * Página de Equipamentos Sem Intervenções
 */
require_once __DIR__ . 
'/../config/ligacao.php';

$mensagem = '';
$tipo_mensagem = '';

// Obter equipamentos sem intervenções
$equipamentos_sem_intervencoes = [];
try {
    $sql = "SELECT e.id_equipamento, e.tipo, e.marca, e.modelo, e.endereco_ip, s.nome_sala, e.data_criacao 
            FROM equipamentos e 
            LEFT JOIN salas s ON e.id_sala = s.id_sala 
            LEFT JOIN intervencoes i ON e.id_equipamento = i.id_equipamento 
            GROUP BY e.id_equipamento 
            HAVING COUNT(i.id_intervencao) = 0 
            ORDER BY e.data_criacao DESC";
    $stmt = $conn->query($sql);
    $equipamentos_sem_intervencoes = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $mensagem = 'Erro ao carregar equipamentos sem intervenções: ' . $e->getMessage();
    $tipo_mensagem = 'error';
}
?>

<h1>Equipamentos Sem Intervenções</h1>
<p class="page-subtitle">Lista de equipamentos que nunca tiveram registo de intervenção</p>

<?php if ($mensagem): ?>
    <div class="alert alert-<?php echo $tipo_mensagem; ?>">
        <?php echo htmlspecialchars($mensagem); ?>
    </div>
<?php endif; ?>

<?php if (!empty($equipamentos_sem_intervencoes)): ?>
    <div class="card mt-4">
        <h2>Detalhes dos Equipamentos</h2>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Tipo</th>
                    <th>Marca</th>
                    <th>Modelo</th>
                    <th>Endereço IP</th>
                    <th>Sala</th>
                    <th>Data de Criação</th>
                    <th>Dias sem Intervenção</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($equipamentos_sem_intervencoes as $row): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['id_equipamento']); ?></td>
                        <td><?php echo htmlspecialchars($row['tipo']); ?></td>
                        <td><?php echo htmlspecialchars($row['marca']); ?></td>
                        <td><?php echo htmlspecialchars($row['modelo']); ?></td>
                        <td><code><?php echo htmlspecialchars($row['endereco_ip']); ?></code></td>
                        <td><?php echo htmlspecialchars($row['nome_sala']); ?></td>
                        <td><?php echo date('d/m/Y H:i', strtotime($row['data_criacao'])); ?></td>
                        <td>
                            <?php
                            $data_criacao = new DateTime($row['data_criacao']);
                            $hoje = new DateTime();
                            $intervalo = $hoje->diff($data_criacao);
                            echo $intervalo->days . ' dias';
                            ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php else: ?>
    <div class="no-data">
        <p>Todos os equipamentos registados tiveram pelo menos uma intervenção.</p>
    </div>
<?php endif; ?>
